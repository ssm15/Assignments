package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
public class  ServiceImplementation implements EmployeeService 
{
	public String  iService(Employee e)
	{
		if((e.getSalary()<5000)&&e.getDesignation().equals("Clerk"))
		{
			return "No Scheme";
		}
		else if((e.getSalary()>5000&&e.getSalary()<20000)&& e.getDesignation().equals("System Associate"))
		{
			return " Scheme C";
		}
		else if((e.getSalary()>20000&&e.getSalary()<50000)&& e.getDesignation().equals("Programmer"))
		{
			return " Scheme B";
		}
		else if((e.getSalary()>40000)&& e.getDesignation().equals("Manager"))
		{
			return " Scheme A";
		}
			
		return "Invalid";
		}
	
		@SuppressWarnings("resource")
		public Employee setDetails()
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter details of Employee :\nId, name, Designation, Salary : ");
			
			return new Employee(sc.nextInt(),sc.next(),sc.nextDouble(),sc.next());
		}
		public void showDetails(Employee e)
		{
			System.out.println("\nEmployee ID :"+e.getEid()+
					"\nEmployee Name:"+e.getEname()+
					"\nEmployee Designation :"+e.getDesignation()+
					"\nEmployee Salary :"+e.getSalary()+
					"\nEmployee Scheme :"+e.getInsuranceScheme());
		}
	}
