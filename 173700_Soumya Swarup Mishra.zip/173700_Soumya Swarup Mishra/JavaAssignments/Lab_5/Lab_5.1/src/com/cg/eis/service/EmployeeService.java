package com.cg.eis.service;

import com.cg.eis.bean.Employee;
public interface EmployeeService {

	public Employee setDetails();
	public String iService(Employee e);
	public void showDetails(Employee e);
}
