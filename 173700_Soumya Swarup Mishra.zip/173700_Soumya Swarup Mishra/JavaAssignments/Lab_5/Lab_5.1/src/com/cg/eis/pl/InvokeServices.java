package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.ServiceImplementation;

public class InvokeServices {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter number of employees :");
int n=sc.nextInt();
Employee e[]=new Employee[n];
ServiceImplementation si=new ServiceImplementation();
for(int i=0;i<n;i++)
{
	e[i]=si.setDetails();
}
for(int i=0;i<n;i++)
{
	e[i].setInsuranceScheme(si.iService(e[i]));
}
System.out.println("Employee Details :");
for(int i=0;i<n;i++)
{
	si.showDetails(e[i]);
	
	sc.close();
}
	}

}
