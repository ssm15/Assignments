package com.cg.model;

public class CreateAccount extends Account {
 public CreateAccount(double balance, Person accHolder)
 {
	 super(balance,accHolder);
 }
}
