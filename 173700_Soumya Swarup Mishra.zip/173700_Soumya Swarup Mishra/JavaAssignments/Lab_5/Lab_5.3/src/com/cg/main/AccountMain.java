package com.cg.main;

import com.cg.model.*;

public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
CreateAccount s=new CreateAccount(2000,new Person("Smith",33));
CreateAccount k=new CreateAccount(3000,new Person("Kathy",23));
s.deposit(2000);
k.withdraw(2000);
System.out.println(s);
System.out.println(k);
	}

}
