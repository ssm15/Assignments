package com.cg.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class SortProductNames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
List<String> l=new ArrayList<String>();
System.out.println("Enter no of elements");
int n=sc.nextInt();
System.out.println("Enter elements of array");
for(int i=0;i<n;i++)
	l.add(sc.next());
System.out.println(l);
Collections.sort(l);
for(Object o:l)
	System.out.println(o+" ");
	sc.close();
	}
}
