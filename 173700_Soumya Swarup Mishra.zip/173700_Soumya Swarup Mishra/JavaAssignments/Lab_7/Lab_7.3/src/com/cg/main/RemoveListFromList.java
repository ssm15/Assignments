package com.cg.main;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class RemoveListFromList {
	
	public List<String> removeElements(List<String> l1,List<String> l2)
	{
		l1.removeAll(l2);
		return l1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
String s;
RemoveListFromList r1=new RemoveListFromList();
List<String>l1=new ArrayList<String>();
List<String>l2=new ArrayList<String>();
System.out.println("Enter elements of bigger list");
System.out.println("exit will be accepted as last element");
do
{
	s=sc.next();
	l1.add(s);
}while(!s.equals("exit"));
System.out.println("Enter elements of smaller list to be removed from bigger");
System.out.println("exit will be accepted as last element");
do
{
	s=sc.next();
	l2.add(s);
}while(!s.equals("exit"));
System.out.println("Bigger List :");
System.out.println(l1);
System.out.println("Smaller List :");
System.out.println(l2);
r1.removeElements(l1,l2);
System.out.println("After removing");
System.out.println(l1);
sc.close();
}

}
