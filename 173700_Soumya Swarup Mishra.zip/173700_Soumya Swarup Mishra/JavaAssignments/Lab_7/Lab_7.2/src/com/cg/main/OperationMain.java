package com.cg.main;

import java.util.*;
public class OperationMain {

	public static List<String> operations (String s1,String s2)
	{
		List<String>temp=new ArrayList<String>();
		//m1
		String p="";
		for(int i=0;i<s1.length();i++)
			p+=(i%2!=0)? s2:s1.charAt(i);
		temp.add(p);
		p="";
		String ns="";
		//m2
		if(((s1.length()-(int)(s1.replace(s2, "")).length())/s1.length())>0)
		{
			for(int i=s2.length()-1;i>=0;i--)
			p+=s2.charAt(i);
			for(int i=0;i<s1.length();i++)
			{
				if(i==s1.lastIndexOf(s2))
				{
					ns+=p;
					i+=s2.length();
				}
				else ns+=s1.charAt(i++);
				}
			temp.add(ns);
			}
		else 
			temp.add(s1+s2);
		//m3
		String s=s1;
		if(((s1.length()-(int)(s1.replace(s2, "")).length())/s2.length())>1)
		{
			s=s.replaceFirst(s2,"");
			temp.add(s);
		}
		else
			temp.add(s1);
		//m4
		s="";
		if(s2.length()%2==0) {
			s=s2.substring(0,s2.length()/2)+s1+s2.substring(s2.length()/2,s2.length());
		temp.add(s);
		}
	else
	{
		s=s2.substring(0,(s2.length()/2)+1)+s1+s2.substring((s2.length()/2)+1,s2.length());
		temp.add(s);
	}
	//m5
	p="";
	for(int i=0;i<s1.length();i++)
	{
		if(s2.contains(String.valueOf(s1.charAt(i))))
			p+="*";
		else
			p+=s1.charAt(i);
	}
	temp.add(p);
	return temp;
}
	
	public static void main (String[] args) {
		// TODO Auto-generated method stub
List<String>output=new ArrayList<String>();
Scanner sc=new Scanner(System.in);
String st1=new String();
String st2=new String();

//String Operations so=new String Operations();

System.out.println("Enter First String :");
st1=sc.next();
System.out.println("\n Enter Second String :");
st2=sc.next();

output=operations(st1,st2);
for(Object o:output)
	System.out.println(o);
sc.close();

	}
}
