package com.cg.eis.service;

import java.util.Comparator;
import com.cg.eis.bean.Employee;

public class  SalaryComparator implements Comparator<Object>
{
	public  SalaryComparator()
	{
		
	}
	@Override
	public int compare(Object emp1, Object emp2)
	{
		double emp1Age=((Employee) emp1).getSalary();
		double emp2Age=((Employee) emp2).getSalary();
		
		if(emp1Age  >  emp2Age)
			return 1;
		else if (emp1Age  < emp2Age)
			return -1;
		else
			return 0;
	}
}