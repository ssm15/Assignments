package com.cg.eis.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.eis.bean.Employee;
public class Service implements EmployeeService {
	HashMap<String,Employee> list = new HashMap<String,Employee>();  
	public Service()
	{
		
	}
	
	public void addEmployee(Employee emp)
	{
		list.put(insuranceScheme(emp),emp);
	}
	@SuppressWarnings("resource")
	public Employee employeeDetails()
	{
		System.out.println("Enter Id,Name,Salary and Designations of Employee");
		Scanner sc=new Scanner(System.in);
		return new Employee(sc.nextInt(),sc.next(),sc.nextDouble(),sc.next());
	}
	public String insuranceScheme(Employee e)
	{
		if(e.getSalary()>40000&&e.getDesignation().equals("Manager"))
			return "Scheme A";
		else if(e.getSalary()>=20000&&e.getDesignation().equals("Programmer"))
			return "Scheme B";
		else if(e.getSalary()>5000&&e.getDesignation().equals("System Associate"))
			return "Scheme C";
		else
			return "NoScheme";
	}
	
	public void showDetails(Employee e)
	{
		System.out.println(e.getEid());
		System.out.println(e.getEname());
		System.out.println(e.getSalary());
		System.out.println(e.getDesignation());
		System.out.println(e.getInsuranceScheme());
	}
	@SuppressWarnings("rawtypes")
	@Override
	public void searchEmployee(String is)
	{
		Set<?> set=list.entrySet();
		Iterator<?> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry me=(Map.Entry) i.next();
			if(is.equals(me.getKey()))
					{
				System.out.println("Required Employee");
				showDetails((Employee)me.getValue());
		  }
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public boolean deleteEmployee(int id)
	{
		Set<?> set=list.entrySet();
		Iterator<?> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry me=(Map.Entry)i.next();
			if(id==((Employee) me.getValue()).getEid())
			{
				System.out.println("Employee:");
				showDetails((Employee)me.getValue());
			System.out.println("Deleted Successfully");
			list.remove(me.getKey());
			}
		}
		return false;
	}
	@SuppressWarnings("rawtypes")
	@Override
	public void showSortedList()
	{
		Set<?> set=list.entrySet();
		List<Employee> l=new ArrayList<Employee>();
		Iterator<?> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry me=(Map.Entry)i.next();
			l.add((Employee)me.getValue());
		}
		Collections.sort(l,new SalaryComparator());
		System.out.println(l);
	}
}
