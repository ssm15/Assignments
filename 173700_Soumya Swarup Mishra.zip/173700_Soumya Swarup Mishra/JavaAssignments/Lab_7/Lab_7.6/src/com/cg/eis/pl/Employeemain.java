package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class Employeemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter number of employees :");
int n=sc.nextInt();
Employee e[]=new Employee[n];
Service s=new Service();
for(int i=0;i<n;i++)
{
	e[i]=s.employeeDetails();
	e[i].setInsuranceScheme(s.insuranceScheme(e[i]));
	s.addEmployee(e[i]);
}
System.out.println("Employee Details are :");
for(int i=0;i<n;i++)
{
	s.showDetails(e[i]);
	System.out.println("Enter Insurance Scheme");
	String is=sc.next();
	s.searchEmployee(is);
  System.out.println("Enter Employee ID to delete");
  int id=sc.nextInt();
s.deleteEmployee(id);
System.out.println("Employees sorted by Salary");
s.showSortedList();
	}
	sc.close();
	}
}
