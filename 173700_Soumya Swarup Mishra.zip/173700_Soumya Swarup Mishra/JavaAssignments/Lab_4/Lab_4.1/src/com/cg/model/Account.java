package com.cg.model;

public class Account {
private long accnumber;
private double balance;
Person accHolder;
static long begin=1;
public Account( double balance, Person accHolder) {
	super();
	this.accnumber = begin++;
	this.balance = balance;
	this.accHolder = accHolder;
}
public long getAccnumber() {
	return accnumber;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Person getAccHolder() {
	return accHolder;
}
public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}
public void deposit(double amount)
{
	balance+=amount;
}
public void withdraw(double amount)
{
	if(balance-amount>=500)
		balance-=amount;
	else System.out.println("Insufficient Balance");
}
@Override
public String toString() {
	return "Account [accnumber=" + accnumber + ", balance=" + balance
			+ ",Account Holder Details :"+ accHolder + "]";
}


}
