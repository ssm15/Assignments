package com.cg.main;

import com.cg.model.*;

public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Account smith=new Account(2000,new Person("Smith",33));
Account kathy=new Account(3000,new Person("Kathy",23));
smith.deposit(2000.00);
kathy.withdraw(2000.00);
System.out.println(smith);
System.out.println(kathy);
	}

}
