package com.cg.main;

import com.cg.model.*;

public class AccountMain {

	public static void main(String[] args) {
		Account account;
account =new SavingAccount(2000,new Person("Smith",33));
System.out.println("Before Deposit :"+account);
account.deposit(2000.00);
System.out.println(account);
account=new CurrentAccount(3000,new Person("Kathy",22));
System.out.println("Before Withdraw :"+account);
account.withdraw(60000);
System.out.println(account);
	}

}