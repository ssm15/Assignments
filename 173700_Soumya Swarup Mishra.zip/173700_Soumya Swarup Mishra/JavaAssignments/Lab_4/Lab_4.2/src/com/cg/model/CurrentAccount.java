package com.cg.model;

public class CurrentAccount extends Account {
private double overdraft;

public CurrentAccount(double balance,Person accHolder) 
{
	super(balance,accHolder);
	//this.overdraft = overdraft;
	this.overdraft = - 2000;
}

public void withdraw(double amount)
{
	if(getBalance()-amount>=overdraft)
	{
		super.withdraw(amount);
	}
	else System.out.println("Balance cannot be below :"+overdraft);
}
public void deposit(double amount)
{
	super.deposit(amount);
}
}
