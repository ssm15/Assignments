package com.cg.main;

import com.cg.model.Person;
import com.cg.model.UserException;

public class PersonMain {

	public static void exp(String fname,String lname) throws UserException {
		if(fname.trim().equals ("")||lname.trim().equals(""))
		{
			throw new UserException(fname,lname,"Blank Found");
		}
	}
	
	public static void main(String[] args)
	{
 Person p= new Person("","",'M');
 try{
	 exp(p.getFirstName(),p.getLastName());
 }
 catch(Exception e)
 {
	 System.out.println("Message :"+e.getMessage());
	System.out.println(e);
	e.printStackTrace();
 }
 
    System.out.println("Person Details:\n__________\n\n");
	System.out.println("First Name: "+p.getFirstName());
	System.out.println("Last Name: "+p.getLastName());
	System.out.println("Gender: "+p.getGender());
	
	}

}
