package com.cg.model;

public class UserException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String fname;
private String lname;
public UserException() {
	super();
	// TODO Auto-generated constructor stub
}
public UserException(String fname, String lname, String message) {
	super(message);
	this.fname = fname;
	this.lname = lname;
}
@Override
public String toString() {
	return "UserException [fname=" + fname + ", lname=" + lname + "]"+getMessage();
}


}
