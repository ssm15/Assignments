package com.cg.main;

import com.cg.model.*;

public class AccountMain {
public static void exp(float age) throws UserException 
{
	if(age<15){
		throw new UserException(age,"Age is less than 15");
	}
}
	
	public static void main(String[] args) {
		Account account;
account =new SavingAccount(2000,new Person("Smith",33));

try
{
	exp(account.getAccHolder().getAge());
}

catch(Exception e){
	System.out.println("Message :"+e.getMessage());
	System.out.println(e);
	e.printStackTrace();
}
System.out.println("Before Deposit :"+account);
account.deposit(2000.00);
System.out.println(account);
account=new CurrentAccount(3000,new Person("Kathy",22));

try
{
	exp(account.getAccHolder().getAge());
}

catch(Exception e){
	System.out.println("Message :"+e.getMessage());
	System.out.println(e);
	e.printStackTrace();
}
System.out.println("Before Withdraw :"+account);
account.withdraw(60000);
System.out.println(account);
	}

}