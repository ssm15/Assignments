package com.cg.model;

public class SavingAccount extends Account {

	final double minimum_balance=500;
	
	public SavingAccount(double balance,Person accHolder)
	{
		super(balance,accHolder);                   
                                        		
	}

public void withdraw(double amount)
{
	if(balance>minimum_balance)
		super.withdraw(amount);
	else System.out.println("Insufficient balance and cannot be less than 500");
}
public void deposit(double amount)
{
	if(amount>0)
	{
	super.deposit(amount);
}
	else
	{
		System.out.println("Invalid Amount");
}
}
}
