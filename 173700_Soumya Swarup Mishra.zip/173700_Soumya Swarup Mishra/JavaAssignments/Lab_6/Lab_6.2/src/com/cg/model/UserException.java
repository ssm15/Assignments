package com.cg.model;

public class UserException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private float age;
	
	public UserException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserException(float age, String message) {
		super(message);
		this.age=age;
	}
	@Override
	public String toString() {
		return "UserException [age=" + age + "]"+getMessage();
	}
	

	}
