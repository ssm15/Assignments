package com.cg.main;

public class PowerUsingLambda {
	public interface PowerFace
	{
		public double power(int num1,int num2);
	}
	public static void main(String [] args)
	{
		PowerFace m=(n1,n2)->
		{
			return Math.pow(n1,n2);
		};
		double p=m.power(2,2);
		System.out.println(p);
	}

}
