package com.cg.main;
interface Name
{
	public void nameString(String s);
}
public class ReferenceMethods {

	String name;
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ReferenceMethods ob=new ReferenceMethods();
Name pl=ob::setName;
pl.nameString("Soumya");
Name p2=System.out::print;
p2.nameString(ob.getName());
	}
}
