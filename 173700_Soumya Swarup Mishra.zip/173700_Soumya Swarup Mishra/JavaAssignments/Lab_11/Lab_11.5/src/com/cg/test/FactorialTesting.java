package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.main.Factorial;

public class FactorialTesting {

		@Test
		public void testingfactMethod(){
			Factorial f=new Factorial();
			assertEquals(720,f.fact(6));
		}
	}
