package com.cg.main;

public class Factorial {
public int fact(int n)
{
	if(n<2) return 1;
	return n*fact(n-1);
}
}
