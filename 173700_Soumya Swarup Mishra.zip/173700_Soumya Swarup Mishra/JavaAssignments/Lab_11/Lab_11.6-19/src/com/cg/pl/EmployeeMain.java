package com.cg.pl;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.cg.model.Employee;
import com.cg.service.EmployeeService;
public class EmployeeMain
{
public static void main(String [] args){
	EmployeeService s=new EmployeeService();
	System.out.println("Sum of salaries");
	System.out.println(s.sumOfSalaries());
	System.out.println("=====================");
	System.out.println("Seniormost Employee");
	System.out.println(s.seniorEmployee().get().getFirstName());
	Map<Integer, List<Employee>> techCount=s.countDep();
	System.out.println("=============================");
	System.out.println("Employee count by Department");
	for(Integer departmentId:techCount.keySet())
	{
		System.out.println(departmentId+":"+techCount.get(departmentId).size());
	}
	System.out.println("==============================");
	Optional<Integer> highest=s.maxEmpByDep();
	System.out.println("Department with maximum Employees ="+highest.get());
	System.out.println("==============================");
	System.out.println("Employee list sorted by Employee Id ");
	s.sortByEmployeeId().forEach(System.out::println);
	System.out.println("==============================");
	System.out.println("Employee list sorted by Department Id");
	s.sortByDepartmentId().forEach(System.out::println);
	System.out.println("==============================");
	System.out.println("Employee list sorted by First Name");
	s.sortByFirstName().forEach(System.out::println);
}
	
}
