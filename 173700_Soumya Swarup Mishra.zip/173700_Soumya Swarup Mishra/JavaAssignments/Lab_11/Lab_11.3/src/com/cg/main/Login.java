package com.cg.main;

import java.util.function.BiPredicate;

public class Login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
BiPredicate<String, String>p=(id,pass)->id.length()>=8&&pass.length()>=8;
System.out.println(p.test("Soumya134","qwertyuiop"));
	}

}
