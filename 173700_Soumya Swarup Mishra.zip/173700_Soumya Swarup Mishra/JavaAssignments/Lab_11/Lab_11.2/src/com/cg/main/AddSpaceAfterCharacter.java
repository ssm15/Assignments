package com.cg.main;

public class AddSpaceAfterCharacter {
	public interface AddSpace {
	public String SpaceAfterCharacter(String s);
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
AddSpace m=(String s)->{
	String str=new String();
	for(int i=0;i<s.length();i++)
	{
		str+=s.charAt(i);
		if(i<s.length()-1)
			str+=" ";
	}
	return str;
	};
	String p=m.SpaceAfterCharacter("Soumya");
	System.out.println(p);
	}
}
