package com.cg.main;

import java.util.Scanner;

public class ArrayStringOperation 
{
public String[] operation(String[] str,int n) 
{
	int k;
	if(n%2==0) k=n/2;
	else k=(n/2)+1;
	for(int i=0;i<k;i++)
{
		str[i]=str[i].toUpperCase();
}
	for(int j=k;j<n;j++)
	{
		str[j]=str[j].toLowerCase();
	}
	return str;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter number of Strings : ");
int n=sc.nextInt();
String []str=new String[n];
int m=1;
for(int i=0;i<n;i++)
{
	System.out.println("Enter Strings ["+(m++)+"] :");
	str[i]=sc.next();
}
for(int i=0;i<str.length-1;i++)
{
	for(int j=i+1;j<str.length;j++)
	{
		if(str[i].compareTo(str[j])>0)
				{
			String temp=str[i];
			str[i]=str[j];
			str[j]=temp;
		}
	}
}
ArrayStringOperation ob=new ArrayStringOperation ();
String[] st=ob.operation(str,n);
int i=1;
System.out.println("After sorting and inserting array is");
for(String oc:st)
{
	System.out.println(" String ["+(i++)+"] :"+oc);
	
	sc.close();
}
	}
}

