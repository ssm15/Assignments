package com.cg.main;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneDateTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
ZonedDateTime.now();
System.out.println("Enter Zone");
String zone=sc.next();
ZonedDateTime datetime=ZonedDateTime.now(ZoneId.of(zone));
System.out.println("Todays date and time :"+datetime);
	
sc.close();
	}
}
