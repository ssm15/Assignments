/*
Revise exercise 3.3 to accept two LocalDates and print the duration between dates in days, months and years
*/

package main;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class TwoInputDates {

	public static void main(String[] args)
	{
		
	    Scanner sc=new Scanner(System.in);
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
		System.out.println("Enter the 1st date in dd/MM/yyyy format :");
		String inputdate1=sc.next();
        LocalDate dateformat1= LocalDate.parse(inputdate1,format);
		LocalDate start=LocalDate.of(dateformat1.getYear(),dateformat1.getMonth(), dateformat1.getDayOfMonth());
		
		System.out.println("Enter the 2nd date in dd/MM/yyyy format :");
		String inputdate2=sc.next();
        LocalDate dateformat2= LocalDate.parse(inputdate2,format);
		LocalDate end=LocalDate.of(dateformat2.getYear(),dateformat2.getMonth(), dateformat2.getDayOfMonth());
		
		Period period=start.until(end);

		System.out.println("Days :"+period.getDays());
		System.out.println("Months :"+period.getMonths());
		System.out.println("Years :"+period.getYears());
		
		sc.close();
	    }

	}
