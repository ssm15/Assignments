package com.cg.model;

public class StringOperation {
public String operation (String str, int decision)
{
	String st="";
	switch(decision)
	{
	case 1: return(str+str);
	
case 2: for(int i=0;i<str.length();i++)
         {
	char c=str.charAt(i);
           if(i%2!=0)
           {
        	 st+="#";  
           }
           else st+=c;
}
return st;
case 3: st+=str.charAt(0);int j;
	
	for(int i=1;i<str.length();i++)
{
		char c=str.charAt(i);
for (j=0;j<st.length();j++)
{
	if (st.charAt(j)==c)
		break;
}
if (j==str.length())
		st+=c;
}
return st;
case 4: for(int i=0;i<str.length();i++)
{
char c=str.charAt(i);
  if(i%2==0)
  {
	 st+=Character.toUpperCase(c);  
  }
  else
  {
	  st+=c;
  }
}
return st;
default: return("======Invalid Input========");
}
}
}
