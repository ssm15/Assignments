package com.cg.main;
import java.util.Scanner;

import com.cg.model.StringOperation;
public class Stringmain {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter a String");
String str=sc.next();
System.out.println("1.Add the String to itself"+"\n"+
	               "2.Replace odd positions with #"+"\n"
		          +"3.Remove duplicate characters in the String"+"\n"
		          +"4.Change odd characters to upper case");

int decision=sc.nextInt();
StringOperation s=new StringOperation();
System.out.println("Output: "+s.operation(str,decision));

sc.close();
	}
}
