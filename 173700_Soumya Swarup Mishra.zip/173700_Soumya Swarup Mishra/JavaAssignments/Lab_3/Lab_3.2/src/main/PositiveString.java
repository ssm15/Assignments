/*                                                 
Create a method that accepts a String and checks if it is a positive string. 
A string is considered a positive string, if on moving from left to right each character in the String comes after the previous 
characters in the Alphabetical order.For Example: ANT is a positive String (Since T comes after N and N comes after A).
The method should return true if the entered string is positive.
 */

  package main;

 import java.util.Scanner;

 public class PositiveString {

 public Boolean check(String str)
 {
 for(int i=(str.length()-1);i>1;i--)
 {
 char a=str.charAt(i);
 char b=str.charAt(i-1);
 if (a<b) return false;
	
 }
 return true;
 }
 public static void main(String[] args) 
 {
	Scanner sc=new Scanner(System.in);
	PositiveString ps=new PositiveString();
	System.out.println("Enter a String");
	String str=sc.next();
	System.out.println("Entered String is Positive or not:"+ps.check(str));
	sc.close();
	}

}
