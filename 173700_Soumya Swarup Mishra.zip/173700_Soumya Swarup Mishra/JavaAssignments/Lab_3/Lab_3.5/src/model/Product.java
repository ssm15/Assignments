package model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Product
{
private Scanner sc;

public LocalDate PurchaseDate()
{
String PurchaseDate=new String();
DateTimeFormatter format= DateTimeFormatter.ofPattern("dd/MM/yyyy");
sc = new Scanner(System.in);
System.out.println("Enter Purchase Date :");
PurchaseDate=sc.next();
LocalDate dateformat=LocalDate.parse(PurchaseDate,format);
LocalDate start=LocalDate.of(dateformat.getYear(),dateformat.getMonth(),dateformat.getDayOfMonth());
return start;
}
}
