package main;

import java.time.LocalDate;
import java.util.Scanner;

import model.Product;

public class ProductValidity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Product p=new Product();
Scanner sc=new Scanner(System.in);
LocalDate start=p.PurchaseDate();
String period=new String();
System.out.println("Enter validity Period in format(MM/year):");
period=sc.next();
String st[]=period.split("/");
int month=start.getMonthValue()+Integer.parseInt(st[0]);
int year=(start.getYear()+Integer.parseInt(st[1]));
if(month>12)
{
	month=month%12;
	year++;
}
System.out.println("Date of expiry :"+start.getDayOfMonth()+"\\"+month+"\\"+year);
sc.close();
}
}
