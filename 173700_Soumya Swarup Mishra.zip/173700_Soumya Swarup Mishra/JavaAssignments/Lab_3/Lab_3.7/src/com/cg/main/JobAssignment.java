package com.cg.main;

import java.util.Scanner;

		public class JobAssignment {
			
		public boolean validate(String user)
		{
			int i=user.indexOf("_job");
			if(user.length()>11&&i==user.length()-4)
			{
				return true;}
				return false;
			}

			public static void main(String[] args) {
				// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Username");
		String user=sc.next();
		JobAssignment ja=new JobAssignment();
		if(ja.validate(user))
		{
			System.out.println("Valid Username");
		}
		else
			System.out.println("InValid Username");
		
		sc.close();
			}
		}
