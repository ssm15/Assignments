/*
Create a method to accept date and print the duration in days, months and years with regards to current system date
 */

package main;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateOperations {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
LocalDate localdate=LocalDate.now(); 

System.out.println("Enter the date in dd/MM/yyyy format :");
String inputdate=sc.next();

LocalDate dateformat=LocalDate.parse(inputdate,format);
LocalDate start=LocalDate.of(dateformat.getYear(),dateformat.getMonth(), dateformat.getDayOfMonth());
Period period=start.until(localdate);

System.out.println("Days :"+period.getDays());
System.out.println("Months :"+period.getMonths());
System.out.println("Years :"+period.getYears());

sc.close();
	}
}
