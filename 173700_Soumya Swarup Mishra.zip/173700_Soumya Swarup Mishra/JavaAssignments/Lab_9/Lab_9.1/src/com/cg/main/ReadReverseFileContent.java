package com.cg.main;

import java.io.FileReader;
import java.io.FileWriter;

public class ReadReverseFileContent {

	private static FileWriter os;
	private static FileReader is;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try
{
	is = new FileReader("source.txt");
	os = new FileWriter("target.txt");

	String str=new String();
	int c;
	while((c=is.read())!=-1)
	{
		str+=(char)c;
		//os.write(c);
	}
	for(int i=str.length()-1;i>=0;i--)
	{
		//System.out.println(str);
	os.write(str.charAt(i));
	}
}
catch(Exception e)
{
	System.out.println(e.getMessage()); 
	
}
}
}
