package com.cg.eis.pl;

import java.io.IOException;
import java.util.Scanner;

import com.cg.eis.bean.*;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.ServiceImplementation;

public class InvokeServices {
	private static Scanner sc;

	public static void exp(double salary) throws EmployeeException 
	{
		if(salary<3000)
		{
			throw new EmployeeException(salary,"salary is below 3000");
		}
	}

	public static void main(String[] args) throws IOException
	{
		sc = new Scanner(System.in);
System.out.println("Enter number of employees :");
int n=sc.nextInt();
Employee e[]=new Employee[n];

ServiceImplementation si=new ServiceImplementation();
for(int i=0;i<n;i++)
{
	e[i]=si.setDetails();
}
try
{
	for(int i=0;i<n;i++)
		exp(e[i].getSalary());
}
catch(Exception ex){
	System.out.println("Message:"+ex.getMessage());
	System.out.println(ex);
	ex.printStackTrace();
}
for(int i=0;i<n;i++)
{
	e[i].setInsuranceScheme(si.iService(e[i]));
}
si.writeToFile(e);
si.readFromFile();
	}
	}
