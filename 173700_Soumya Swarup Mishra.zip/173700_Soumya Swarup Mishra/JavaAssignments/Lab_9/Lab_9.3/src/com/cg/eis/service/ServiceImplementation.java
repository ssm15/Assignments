package com.cg.eis.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.IOException;
import java.io.FileNotFoundException;
import com.cg.eis.bean.Employee;
public class ServiceImplementation implements EmployeeService
{
	private Scanner sc;
	private PrintWriter pw;
	private Scanner sc2;
	public String iService(Employee e)
	{
		if((e.getSalary()<5000)&&e.getDesignation().equals("Clerk")){
			return "NoScheme";
		}
		else if((e.getSalary()>5000&&e.getSalary()<20000)&& e.getDesignation().equals("System Associate"))
		{
			return "Scheme C";
		}
		else if((e.getSalary()>=20000&&e.getSalary()<50000)&&e.getDesignation().equals("Programmer"))
		{
			return "Scheme B";
		}
		else if((e.getSalary()>40000)&&e.getDesignation().equals("Manager"))
		{
			return "Scheme A";
		}
		else
			return "Invalid";
	}
	public Employee setDetails()
	{
		sc = new Scanner(System.in);
		System.out.println("Enter details of Employee:\nId,Name,salary,Designation: ");
		return new Employee(sc.nextInt(),sc.next(),sc.nextDouble(),sc.next());
	
	}
	public void showDetails(Employee e)
	{
		System.out.println("\nEmployee ID:"+e.getEid()+
		"\nEmployee Name:"+e.getEname()+
		"\nEmployee Designation:"+e.getDesignation()+
		"\nEmployee Salary:"+e.getSalary()+
		"\nEmployee Scheme:"+e.getInsuranceScheme());
	}
	@Override
	public void writeToFile(Employee[]e) throws IOException
	{
		FileWriter fw=new FileWriter("Employee.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		pw = new PrintWriter(bw);
		for(int i=0;i<e.length;i++)
		{
			pw.println(e[i].getEid()+","+e[i].getEname()+","+e[i].getDesignation()+","
		+e[i].getInsuranceScheme());
			pw.flush();
		}
	}
	@Override
	public void readFromFile()throws FileNotFoundException
	{
		File file=new File("Employee.txt");
		sc2 = new Scanner(file);
	System.out.println("Employee File has:");
	sc2.useDelimiter(",");
	System.out.println(" ID "+"\tName "+"\t\t  Salary "+"\t Designation "+"\t Scheme");
	while(sc2.hasNext())
	{
		System.out.println(sc2.next()+"\t ");
	}
	}
}
	