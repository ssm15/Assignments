package com.cg.main;
import java.io.File;
import java.util.Scanner;
public class DelimitAndPrintEven {

	private static Scanner sc;

	public static void main(String[] args){
		// TODO Auto-generated method stub
File file=new File("source.txt");
try
{
	sc = new Scanner(file);
	sc.useDelimiter(",");
	System.out.println("Even Numbers: ");
	while(sc.hasNext())
	{
		int n=Integer.parseInt(sc.next());
		if(n%2==0)
			System.out.println(n);
	}
}
catch(Exception e)
{
	System.out.println(e.getMessage());
	
}
	}

}
