package com.cg.model;

public enum Gender
{
M,F;
}
