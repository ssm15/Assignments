package com.cg.main;

import com.cg.model.*;

public class PersonMain {

	public static void main(String[] args)
	{
 Person p= new Person("Soumya","Mishra",Gender.M,9438588337l );
 
   p.getDetails();
	}

}
