package com.cg.model;

public class Person
{
private String firstName;
private String lastName;
private char gender;
private long phoneNumber;
public Person()
{
	
}

public Person(String firstName, String lastName, char gender,long phoneNumber) 
{
	this.firstName = firstName;
	this.lastName = lastName;
	this.gender = gender;
	this.phoneNumber = phoneNumber;
}

public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName =firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public char getGender() {
	return gender;
}
public void setGender(char gender) {
	this.gender = gender;
}
public long getPhoneNumber() {
	return phoneNumber;
}

public void setPhoneNumber(long phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public void getDetails()
{
	 System.out.println("Person Details:\n__________\n");
		System.out.println("First Name: "+getFirstName());
		System.out.println("Last Name: "+getLastName());
		System.out.println("Gender: "+getGender());
		System.out.println("Phone Number: "+getPhoneNumber());
}
} 
