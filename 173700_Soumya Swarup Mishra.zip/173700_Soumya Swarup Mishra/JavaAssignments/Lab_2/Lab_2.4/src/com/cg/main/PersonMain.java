package com.cg.main;

import com.cg.model.Person;

public class PersonMain {

	public static void main(String[] args)
	{
 Person p= new Person("Soumya","Mishra",'M',9438588337l );
 
   p.getDetails();
	}

}
