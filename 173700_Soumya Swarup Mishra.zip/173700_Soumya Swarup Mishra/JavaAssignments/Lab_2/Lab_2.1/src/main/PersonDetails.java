//Write a java program to print person details in the format as shown below:

package main;
public class PersonDetails
{
	public static void main(String[] args)
	{
		
System.out.println("Person Details:\n__________\n");
System.out.println("First Name: "+"Soumya");
System.out.println("Last Name: "+"Mishra");
System.out.println("Gender: "+"M");
System.out.println("Age: "+"22");
System.out.println("Weight: "+"78.5");
	}

}
