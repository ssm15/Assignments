package com.cg.main;

import com.cg.model.ThreadClass;
public class ThreadMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ThreadClass m=new ThreadClass();
Thread thread1=new Thread(m,"Number");
Thread thread2=new Thread(m,"Factorial");

thread1.start();
thread2.start();

try
{
	thread1.join();
	thread2.join();	
}
catch(InterruptedException e)
{
	System.err.println(e.getMessage());
	e.printStackTrace();
}
	}

}
