package com.cg.model;

import java.util.Random;

public class ThreadClass implements Runnable {
	int number;
	Random r=new Random();
	boolean valueSet=true;
	@Override
	public void run()
	{
		String option=Thread.currentThread().getName();
		for(int i=0;i<10;i++)
		{
			if(option=="Number")
			{
				printNumber();
			}
			if(option=="Factorial")
				printFactorial();
		}
	}
		public synchronized void printNumber()
		{
			if(!valueSet){
				try 
				{
					wait();
				}
				catch(InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			else
			{
				number=r.nextInt(10);
				System.out.println("Number : "+number);
				valueSet=false;
				notify();
			}
		}
		public synchronized void printFactorial()
		{
			if(!valueSet){
				try 
				{
					wait();
				}
				catch(InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			else
			{
				int f=1,i=number;
				while(i!=1)
				{
					f*=i;
					i--;
				}
				System.out.println("Factorial of  "+number+":"+f);
				valueSet=true;
				notify();
			}
		}
	
	}
