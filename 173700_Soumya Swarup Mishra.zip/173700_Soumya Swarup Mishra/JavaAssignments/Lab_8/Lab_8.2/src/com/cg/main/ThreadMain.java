package com.cg.main;

import com.cg.model.CopyDataThread;

public class ThreadMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CopyDataThread h=new CopyDataThread();
		Thread th=new Thread(h);
		th.start();
	}

}
