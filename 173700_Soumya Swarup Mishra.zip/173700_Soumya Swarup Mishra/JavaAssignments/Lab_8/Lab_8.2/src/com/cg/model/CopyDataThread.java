package com.cg.model;

public class CopyDataThread implements Runnable 
	
	{
		public void run()
		{
			int count=1;
			try
			{
				for(int i=0;i<33;i++)
				{
					System.out.println(count++);
					Thread.sleep(1000);
					if(count==11)
					{
						count=1;
					}
				}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
			}