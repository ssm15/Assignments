package com.cg.model;
import java.io.*;

public class CopyDataThread extends Thread {
public void run()
{
	try
	{
		FileReader is=new FileReader("source.txt");
		
		FileWriter os=new FileWriter("target.txt");
		int c,count=1;
		while((c=is.read())!=-1){
			count++;
			os.write((char )c);
			if(count==10)
			{
				System.out.println("10 characters are copied");
				sleep(5000);
				count=1;
			}
		}
		os.close();
		is.close();
	}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
}
}