package com.cg.main;

import com.cg.model.CopyDataThread;

public class FileProgram 
{
public static void main(String[] args)
{
	Thread h=new CopyDataThread();
	h.start();
}
}
