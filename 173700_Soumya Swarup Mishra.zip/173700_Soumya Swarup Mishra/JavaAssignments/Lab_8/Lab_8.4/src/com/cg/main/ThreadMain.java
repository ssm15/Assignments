package com.cg.main;

import com.cg.runnable.ProductRunnable;
public class ThreadMain 
{

	public static void main(String[] args) {
		ProductRunnable<Object> pr=new ProductRunnable<Object>();
Thread thread=new Thread(pr,"Start Shopping");
thread.start();
try
{
	thread.join();
}
catch(InterruptedException e)
{
	System.out.println(e.getMessage());
}
pr.bill();
	}

}
