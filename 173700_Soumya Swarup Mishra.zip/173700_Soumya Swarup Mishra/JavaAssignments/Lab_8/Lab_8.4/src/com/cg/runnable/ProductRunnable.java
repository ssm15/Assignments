package com.cg.runnable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
public class ProductRunnable<E> implements Runnable
{
HashMap<String, Integer> m=new HashMap<String, Integer>();
private Scanner sc;

@Override
public void run()
{
	sc = new Scanner(System.in);
	System.out.println("Enter your products and their prices and at the end");
	while(true)
	{
		String s=sc.next();
		if(s.equals("exit"))
			break;
		int p=sc.nextInt();
		m.put(s,p);
	}
}
@SuppressWarnings("rawtypes")
public void bill()
{
	int sum=0;
	Set<?> set=m.entrySet();
	Iterator<?> i=set.iterator();
	while(i.hasNext())
	{
		Map.Entry me=(Map.Entry) i.next();
		sum+=(int)me.getValue();
	}
	System.out.println("Total Bill:"+sum);
}
}
