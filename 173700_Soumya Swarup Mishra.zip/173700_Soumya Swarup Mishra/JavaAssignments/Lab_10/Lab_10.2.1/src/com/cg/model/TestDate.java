package com.cg.model;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestDate
{
Date d=null;
static int i=1;

@Before
public void setUp()
{
	System.out.println("Start"+i+" Test ");
	d=new Date(2,12,1999);
}
@After
public void tearDown()
{
	System.out.println("Test"+i+" Ended ");
	d=null;
	i++;
}
@Test
public void testGetDay()
{
	assertEquals(2,d.getDay());
}
@Test
public void testGetMonth()
{
	assertEquals(12,d.getMonth());
}
@Test
public void testGetYear()
{
	assertEquals(12,d.getYear());
}
@Test
public void testSetDay()
{
	d.setDay(30);
	assertEquals(30,d.getDay());
}
@Test
public void testSetMonth()
{
	d.setDay(12);
	assertEquals(12,d.getMonth());
}
@Test
public void testSetYear()
{
	d.setDay(2020);
	assertEquals(2020,d.getYear());
}
}
