package com.cg.test;

import com.cg.eis.exception.EmployeeException;

public class ExceptionCheck {
public boolean checkSalary(double salary) throws EmployeeException
{
	boolean b=true;
	if(salary<3000)
		throw new EmployeeException(salary,"salary must be above 3000");
	else b=false;
	return b;
}
}
