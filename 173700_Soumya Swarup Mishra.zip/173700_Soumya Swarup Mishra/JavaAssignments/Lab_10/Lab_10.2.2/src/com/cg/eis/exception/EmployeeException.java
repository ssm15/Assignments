package com.cg.eis.exception;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double salary;

	public EmployeeException() {
		super();
	}

	public EmployeeException(double salary,String message) {
		super(message);
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "EmployeeException [salary=" + salary + "]"+getMessage();
	}

	
}
