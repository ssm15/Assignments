package com.cg.eis.service;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.cg.eis.bean.Employee;
public interface EmployeeService {

	public Employee setDetails();
	public String iService(Employee e);
	public void showDetails(Employee e);
	public  void writeToFile(Employee[] e)throws IOException;
	public  void readFromFile()throws FileNotFoundException;
}